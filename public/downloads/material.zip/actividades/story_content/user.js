function ExecuteScript(strId)
{
  switch (strId)
  {
      case "61kh3CRWW3H":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

